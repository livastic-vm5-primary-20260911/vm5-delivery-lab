# Package notes — 2026-10-26

- Packaged the current self-contained HTML/CSS/ES module source.
- Added a concise start guide, limited single-project commercial-use terms, publisher page and original responsive QA captures.
- No runtime dependency bundle, API keys, personal records or private wallet material is included.
