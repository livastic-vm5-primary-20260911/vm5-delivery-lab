# Echobloom Atlas — HTML5 Puzzle Starter Kit

Thanks for supporting the original VM5 Delivery Lab project.

## Quick start

1. Extract the folder to a local directory.
2. Serve it over HTTP rather than opening `index.html` directly, for example `python3 -m http.server 8000` from this folder.
3. Open `http://localhost:8000/` in a modern browser.
4. Read `ORIGINAL_PROJECT_README.md` for mechanics and QA; edit the puzzle layout and CSS in the included files.

## Included

- Self-contained browser game: HTML, CSS and native ES modules.
- 18 deterministic guaranteed-solvable logic puzzles with undo/replay and parity-correct hints.
- Keyboard and touch interaction, responsive layouts, accessibility labels, reduced-motion support and local-only progress.
- Original publisher inquiry page, and desktop/mobile QA captures.
- No runtime third-party libraries, ads, analytics, login, server, wallet or remote gameplay API.

## License — personal / single-project commercial use

You may use the included source to learn, modify and publish **one** end product under your own brand, including a commercial game, subject to the exclusions below. You may adapt game logic, styling and puzzle content and ship a compiled or bundled game to end users.

You may not resell or redistribute the unmodified or source-equivalent starter kit as a template, source pack, asset pack or competing product; distribute the files as a standalone source-code download; claim authorship of the original unmodified package; or use it for unlawful, exploitative or deceptive products. Do not remove third-party notices if you add third-party assets later. This license does not grant rights to assets or dependencies that you add yourself.

The underlying project was produced with AI assistance. The seller offers this license to the extent it holds the applicable rights, but does not promise that every jurisdiction treats every AI-assisted element as protectable intellectual property. No exclusive ownership is transferred, and no advice about legal rights is provided.

## Scope and support

This is a source starter kit, not a turnkey revenue guarantee, game-publishing acceptance promise, game-store account, paid ads bundle or guaranteed-profit scheme. Purchasers receive the files in the ZIP. No ongoing support or future updates are included unless agreed separately.

## Seller disclosure

An AI-assisted project from VM5 Delivery Lab. The game is free to play online at the original public demo; this paid product is the source/developer kit and its limited use license, not a charge for access to that free demo.
